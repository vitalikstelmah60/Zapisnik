import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})



export class TasksComponent implements OnInit {

  points = [];

  tasks:string[];

  completed:boolean = false;

  constructor() { }

 

  ngOnInit(){
  	this.tasks = ["Create SocNetwork project", "Start doing KPZ"];
    let temp = {
      task : "Треба здати лаби",
      completed : false
    };
    
    this.points.push(temp);
    console.log(this.points[0].task);
  }

  addtask(ttask){
    let temp = {
      task : ttask,
      completed : false
    };
    this.points.push(temp);  		
    return false;
  }

  doneTask(task){
    console.log(task.completed);
    task.completed = true;
    console.log(task.completed);
    return false;
  }

  deleteTask(taskk){
    console.log(this.points.length);
    console.log(taskk.task);
    console.log(this.points[0].task);
  	for(let i = 0; i<this.points.length; i++){
  		if(this.points[i].task == taskk){
  			this.points.splice(i,1);
  			break;
  		}
  	}
  }

}
class zapis {

    tasks: string;
    completed:boolean;
    constructor(tsk :string) {
 
        this.tasks = tsk;
        this.completed = false;
    }
    gettasks():string{
      return this.tasks;
    }
    getcomp():boolean{
      return this.completed;
    }
    
}